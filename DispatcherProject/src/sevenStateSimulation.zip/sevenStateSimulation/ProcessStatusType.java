package sevenStateSimulation;

/**
 * 
 * @author Gabriel
 *
 */
public enum ProcessStatusType {
	NEW, READY, RUNNING, BLOCKED, EXIT, BLOCKEDSUSPEND, READYSUSPEND
}
